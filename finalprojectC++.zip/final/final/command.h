#pragma once

#include "myController.h"

class command {
public:

	virtual void execute() = 0;
};