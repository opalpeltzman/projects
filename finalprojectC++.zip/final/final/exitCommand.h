#pragma once

#include "command.h"

class exitCommand : public command {
public:

	exitCommand() {}

	void execute() {

	}
	
};
