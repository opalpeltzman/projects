#pragma once

#include "Maze2dGenerator.h"
#include "cell.h"

#include <iostream>
class TestMazeGenerator
{
public:
	TestMazeGenerator() {}

	void testMazeGenerator(Maze2dGenerator& mg);
};

